-- Membership Types
CREATE TABLE MembershipType (
    MembershipTypeID INT PRIMARY KEY,
    TypeName VARCHAR2(50) NOT NULL,
    Price NUMBER(8,2) NOT NULL,
    MaxClassesPerWeek INT,
    AccessTime VARCHAR2(50)
);

-- Members
CREATE TABLE Member (
    MemberID INT PRIMARY KEY,
    FirstName VARCHAR2(50),
    LastName VARCHAR2(50),
    DateOfBirth DATE,
    Gender VARCHAR2(10),
    Email VARCHAR2(100),
    Phone VARCHAR2(20),
    MembershipTypeID INT,
    FOREIGN KEY (MembershipTypeID) REFERENCES MembershipType(MembershipTypeID)
);

-- Trainers
CREATE TABLE Trainer (
    TrainerID INT PRIMARY KEY,
    FirstName VARCHAR2(50),
    LastName VARCHAR2(50),
    Specialization VARCHAR2(100),
    Email VARCHAR2(100),
    Phone VARCHAR2(20)
);

-- Fitness Classes
CREATE TABLE FitnessClass (
    ClassID INT PRIMARY KEY,
    ClassName VARCHAR2(100),
    Description VARCHAR2(1000),
    Duration INT,
    MaxParticipants INT
);

-- Class Schedule
CREATE TABLE ClassSchedule (
    ScheduleID INT PRIMARY KEY,
    ClassID INT,
    TrainerID INT,
    StartTime TIMESTAMP,
    EndTime TIMESTAMP,
    DayOfWeek VARCHAR2(15),
    RoomNumber VARCHAR2(10),
    FOREIGN KEY (ClassID) REFERENCES FitnessClass(ClassID),
    FOREIGN KEY (TrainerID) REFERENCES Trainer(TrainerID)
);

-- Class Enrollments
CREATE TABLE ClassEnrollment (
    EnrollmentID INT PRIMARY KEY,
    MemberID INT,
    ScheduleID INT,
    EnrollmentDate DATE,
    FOREIGN KEY (MemberID) REFERENCES Member(MemberID),
    FOREIGN KEY (ScheduleID) REFERENCES ClassSchedule(ScheduleID)
);

-- Personal Training Sessions
CREATE TABLE PersonalTrainingSession (
    SessionID INT PRIMARY KEY,
    MemberID INT,
    TrainerID INT,
    SessionDate DATE,
    Duration INT,
    FOREIGN KEY (MemberID) REFERENCES Member(MemberID),
    FOREIGN KEY (TrainerID) REFERENCES Trainer(TrainerID)
);

-- Payments
CREATE TABLE Payment (
    PaymentID INT PRIMARY KEY,
    MemberID INT,
    PaymentDate DATE,
    Amount NUMBER(8,2),
    PaymentMethod VARCHAR2(50),
    FOREIGN KEY (MemberID) REFERENCES Member(MemberID)
);

INSERT INTO MembershipType (MembershipTypeID, TypeName, Price, MaxClassesPerWeek, AccessTime) VALUES (1, 'Basic', 30.0, 2, 'All hours');
INSERT INTO MembershipType (MembershipTypeID, TypeName, Price, MaxClassesPerWeek, AccessTime) VALUES (2, 'Premium', 60.0, NULL, 'All hours');
INSERT INTO MembershipType (MembershipTypeID, TypeName, Price, MaxClassesPerWeek, AccessTime) VALUES (3, 'Student', 25.0, 3, 'Off-peak');

INSERT INTO MembershipType (MembershipTypeID, TypeName, Price, MaxClassesPerWeek, AccessTime) VALUES (1, 'Basic', 30.0, 2, 'All hours');
INSERT INTO MembershipType (MembershipTypeID, TypeName, Price, MaxClassesPerWeek, AccessTime) VALUES (2, 'Premium', 60.0, NULL, 'All hours');
INSERT INTO MembershipType (MembershipTypeID, TypeName, Price, MaxClassesPerWeek, AccessTime) VALUES (3, 'Student', 25.0, 3, 'Off-peak');


INSERT INTO Trainer (TrainerID, FirstName, LastName, Specialization, Email, Phone) VALUES (1, 'Brian', 'Miller', 'Yoga', 'hesschristopher@yahoo.com', '+1-597-568-5125x022');
INSERT INTO Trainer (TrainerID, FirstName, LastName, Specialization, Email, Phone) VALUES (2, 'Andrew', 'Blackwell', 'Zumba', 'gutierrezbryan@robles-buck.org', '001-251-607-5949');
INSERT INTO Trainer (TrainerID, FirstName, LastName, Specialization, Email, Phone) VALUES (3, 'Anthony', 'Lang', 'Zumba', 'gbrown@johnson.com', '(905)787-7108x6408');
INSERT INTO Trainer (TrainerID, FirstName, LastName, Specialization, Email, Phone) VALUES (4, 'Cody', 'Serrano', 'Yoga', 'stephanie70@gmail.com', '400.652.8222x23950');
INSERT INTO Trainer (TrainerID, FirstName, LastName, Specialization, Email, Phone) VALUES (5, 'Timothy', 'Barron', 'Pilates', 'perezcynthia@yahoo.com', '(353)267-5926');
INSERT INTO Trainer (TrainerID, FirstName, LastName, Specialization, Email, Phone) VALUES (6, 'Annette', 'Smith', 'Pilates', 'lhiggins@smith.net', '0019922606');
INSERT INTO Trainer (TrainerID, FirstName, LastName, Specialization, Email, Phone) VALUES (7, 'Samuel', 'Mcintyre', 'Pilates', 'sandracox@gmail.com', '+1-612-695-1663');
INSERT INTO Trainer (TrainerID, FirstName, LastName, Specialization, Email, Phone) VALUES (8, 'Thomas', 'Walker', 'Yoga', 'deannasanders@hotmail.com', '448-580-9973');
INSERT INTO Trainer (TrainerID, FirstName, LastName, Specialization, Email, Phone) VALUES (9, 'Joshua', 'Carr', 'Yoga', 'fergusonmelissa@gmail.com', '001-606-661-7972x257');
INSERT INTO Trainer (TrainerID, FirstName, LastName, Specialization, Email, Phone) VALUES (10, 'Robert', 'Lawrence', 'Yoga', 'mahoneymichael@hotmail.com', '(780)342-9546x048');

INSERT INTO FitnessClass (ClassID, ClassName, Description, Duration, MaxParticipants) VALUES (1, 'Yoga', 'Relaxing and meditative', 60, 20);
INSERT INTO FitnessClass (ClassID, ClassName, Description, Duration, MaxParticipants) VALUES (2, 'Zumba', 'Dance-based cardio', 45, 25);
INSERT INTO FitnessClass (ClassID, ClassName, Description, Duration, MaxParticipants) VALUES (3, 'CrossFit', 'High-intensity training', 60, 15);
INSERT INTO FitnessClass (ClassID, ClassName, Description, Duration, MaxParticipants) VALUES (4, 'Pilates', 'Core strength and flexibility', 50, 20);
INSERT INTO FitnessClass (ClassID, ClassName, Description, Duration, MaxParticipants) VALUES (5, 'HIIT', 'High-intensity interval training', 30, 15);
INSERT INTO FitnessClass (ClassID, ClassName, Description, Duration, MaxParticipants) VALUES (6, 'Spin', 'Indoor cycling', 45, 20);

INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (1, 'Megan', 'Chang', TO_DATE('1987-12-12', 'YYYY-MM-DD'), 'Female', 'tammy76@faulkner-howard.com', '242.194.8924x11578', 2);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (2, 'Craig', 'Hamilton', TO_DATE('2000-11-23', 'YYYY-MM-DD'), 'Male', 'hramos@brown-sellers.com', '609-753-5139', 2);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (3, 'Jeffrey', 'Pratt', TO_DATE('1969-01-08', 'YYYY-MM-DD'), 'Female', 'millerluke@hotmail.com', '148.418.5839x8947', 2);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (4, 'Christopher', 'Yates', TO_DATE('1980-11-25', 'YYYY-MM-DD'), 'Female', 'ivan20@zavala.com', '(018)684-8339', 2);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (5, 'Marcia', 'Barnes', TO_DATE('1978-01-20', 'YYYY-MM-DD'), 'Female', 'skeller@yahoo.com', '591-795-3304', 3);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (6, 'Dave', 'Robinson', TO_DATE('1970-12-05', 'YYYY-MM-DD'), 'Male', 'gcabrera@gmail.com', '001-309-891-0139x916', 3);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (7, 'Christopher', 'Bass', TO_DATE('1967-03-23', 'YYYY-MM-DD'), 'Male', 'leetara@martinez.com', '+1-691-413-1456', 2);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (8, 'Henry', 'Gordon', TO_DATE('1962-01-02', 'YYYY-MM-DD'), 'Male', 'wgonzalez@harrison.com', '001-022-584-1907698', 1);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (9, 'Samantha', 'Banks', TO_DATE('1985-10-09', 'YYYY-MM-DD'), 'Female', 'annsmith@hotmail.com', '508-423-7594', 3);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (10, 'Emily', 'Garza', TO_DATE('2002-06-14', 'YYYY-MM-DD'), 'Male', 'paul61@wheeler.com', '(337)696-0696', 2);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (11, 'Kelsey', 'Fletcher', TO_DATE('1970-08-07', 'YYYY-MM-DD'), 'Male', 'greeneric@hotmail.com', '890.075.4706x3812', 3);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (12, 'Valerie', 'Morales', TO_DATE('2005-07-01', 'YYYY-MM-DD'), 'Male', 'aaron00@hotmail.com', '913.193.4421x76104', 3);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (13, 'Robin', 'Marsh', TO_DATE('1967-03-16', 'YYYY-MM-DD'), 'Female', 'desireeroth@hotmail.com', '(124)000-3485x590', 2);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (14, 'Meghan', 'Ali', TO_DATE('2000-09-02', 'YYYY-MM-DD'), 'Male', 'xbowman@hotmail.com', '(369)402-2455', 2);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (15, 'Kristine', 'Higgins', TO_DATE('1982-05-06', 'YYYY-MM-DD'), 'Female', 'nelsonedward@roberts.com', '730-428-1465', 2);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (16, 'Kevin', 'Rodriguez', TO_DATE('1997-06-28', 'YYYY-MM-DD'), 'Male', 'zrogers@yahoo.com', '717-604-5229', 3);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (17, 'Nicholas', 'Villegas', TO_DATE('2002-10-20', 'YYYY-MM-DD'), 'Female', 'mortonjames@brown.com', '(884)779-3615x3492', 2);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (18, 'Ryan', 'Howard', TO_DATE('1963-09-03', 'YYYY-MM-DD'), 'Female', 'mgoodwin@crawford.com', '+1-039-213-7658x2197', 1);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (19, 'Eddie', 'Sullivan', TO_DATE('2005-08-05', 'YYYY-MM-DD'), 'Male', 'ushelton@yahoo.com', '389.305.5508x2492', 1);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (20, 'Megan', 'Aguilar', TO_DATE('1991-05-04', 'YYYY-MM-DD'), 'Female', 'blackruth@perez.com', '7522758688', 3);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (21, 'Arthur', 'Davis', TO_DATE('1994-07-29', 'YYYY-MM-DD'), 'Male', 'nbullock@nichols-george.info', '(993)002-4894x5174', 3);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (22, 'Sherri', 'Turner', TO_DATE('1987-02-04', 'YYYY-MM-DD'), 'Female', 'pbrown@gmail.com', '450.076.2791', 2);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (23, 'Emily', 'Hernandez', TO_DATE('1983-05-02', 'YYYY-MM-DD'), 'Male', 'carrpaul@gmail.com', '720-099-2518', 3);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (24, 'Deborah', 'Lee', TO_DATE('1992-09-09', 'YYYY-MM-DD'), 'Female', 'bishoptanner@peck.org', '264-183-0675x3751', 3);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (25, 'Sue', 'Winters', TO_DATE('1962-01-17', 'YYYY-MM-DD'), 'Male', 'rachel89@hotmail.com', '318.868.4126', 1);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (26, 'Patricia', 'Henderson', TO_DATE('1965-01-16', 'YYYY-MM-DD'), 'Male', 'abrown@navarro.info', '(607)541-5115x05520', 1);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (27, 'Maria', 'Hall', TO_DATE('1984-03-21', 'YYYY-MM-DD'), 'Male', 'jaredharris@dennis.com', '(093)227-1754x203', 3);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (28, 'Michael', 'Kennedy', TO_DATE('1979-03-29', 'YYYY-MM-DD'), 'Female', 'jack11@hotmail.com', '001-426-223-5833', 1);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (29, 'Kari', 'Carter', TO_DATE('1987-11-22', 'YYYY-MM-DD'), 'Male', 'carolynlong@jones.com', '001-645-137-5806', 2);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (30, 'Ricky', 'Butler', TO_DATE('1981-02-23', 'YYYY-MM-DD'), 'Female', 'nathanfarley@gmail.com', '(141)892-7626', 1);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (31, 'Ryan', 'Wright', TO_DATE('1990-03-08', 'YYYY-MM-DD'), 'Female', 'michaelwelch@gmail.com', '340.797.0341x4892', 3);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (32, 'Roger', 'Potter', TO_DATE('1965-08-16', 'YYYY-MM-DD'), 'Female', 'amysullivan@hotmail.com', '1400468967', 3);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (33, 'Curtis', 'King', TO_DATE('1978-08-11', 'YYYY-MM-DD'), 'Male', 'johnsonlaura@ferguson-wilson.com', '001-216-448-2981686', 3);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (34, 'Judith', 'Strong', TO_DATE('1978-04-15', 'YYYY-MM-DD'), 'Female', 'owatson@gmail.com', '(116)697-2845', 3);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (35, 'Crystal', 'Newton', TO_DATE('1974-02-28', 'YYYY-MM-DD'), 'Male', 'uneal@yahoo.com', '+1-074-270-9305x7608', 3);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (36, 'Tiffany', 'Mcdaniel', TO_DATE('1964-11-11', 'YYYY-MM-DD'), 'Female', 'warddarren@gmail.com', '432-943-1675x625', 2);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (37, 'Robert', 'Prince', TO_DATE('1988-12-11', 'YYYY-MM-DD'), 'Male', 'jfitzpatrick@stewart.com', '(676)337-3906x0312', 3);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (38, 'Michael', 'Paul', TO_DATE('2005-06-06', 'YYYY-MM-DD'), 'Female', 'cherylsalazar@melton.com', '(708)869-7747x35400', 2);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (39, 'Brian', 'Bailey', TO_DATE('1979-01-18', 'YYYY-MM-DD'), 'Male', 'brycepatterson@arellano.net', '735.919.1558', 2);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (40, 'Stephen', 'Nguyen', TO_DATE('1961-04-15', 'YYYY-MM-DD'), 'Male', 'miguelclark@reed.com', '864-753-0481x0777', 1);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (41, 'Brandon', 'Lamb', TO_DATE('1992-11-30', 'YYYY-MM-DD'), 'Male', 'fwilson@gmail.com', '263-791-6860', 1);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (42, 'Susan', 'Wright', TO_DATE('1974-04-20', 'YYYY-MM-DD'), 'Female', 'sarah56@hawkins.org', '+1-347-897-8443', 2);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (43, 'Allen', 'Mendez', TO_DATE('1966-01-21', 'YYYY-MM-DD'), 'Male', 'swright@osborn.biz', '1641953843', 1);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (44, 'Jodi', 'Valenzuela', TO_DATE('1963-09-26', 'YYYY-MM-DD'), 'Male', 'jesus74@hotmail.com', '(208)855-9026', 1);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (45, 'Eric', 'Thompson', TO_DATE('1964-07-12', 'YYYY-MM-DD'), 'Male', 'kimberlyhampton@saunders.com', '659.927.1908', 1);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (46, 'Caitlin', 'Burns', TO_DATE('1980-05-01', 'YYYY-MM-DD'), 'Female', 'angelamartin@lamb-mclaughlin.net', '142-963-5460x30535', 3);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (47, 'Michelle', 'Barnett', TO_DATE('2004-03-22', 'YYYY-MM-DD'), 'Female', 'max24@kelly.com', '001-250-700-3005105', 3);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (48, 'Teresa', 'Henderson', TO_DATE('1974-01-22', 'YYYY-MM-DD'), 'Male', 'tthomas@gmail.com', '+1-566-064-8870x9166', 1);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (49, 'George', 'Mason', TO_DATE('2001-08-23', 'YYYY-MM-DD'), 'Female', 'riveramary@wright.com', '001-821-691-29x9045', 3);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (50, 'Linda', 'Oconnor', TO_DATE('1961-03-07', 'YYYY-MM-DD'), 'Female', 'sdavis@hernandez.biz', '476-048-4870x89840', 2);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (51, 'Stephen', 'Griffith', TO_DATE('1986-10-20', 'YYYY-MM-DD'), 'Female', 'rwilliams@hotmail.com', '4943885643', 3);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (52, 'Darren', 'Holden', TO_DATE('1975-11-03', 'YYYY-MM-DD'), 'Female', 'sabrinalam@yahoo.com', '001-090-925-45x7696', 1);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (53, 'Vanessa', 'Smith', TO_DATE('1968-11-26', 'YYYY-MM-DD'), 'Female', 'amartinez@castillo.com', '001-931-864-21x2918', 3);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (54, 'Crystal', 'Daniels', TO_DATE('1985-07-03', 'YYYY-MM-DD'), 'Male', 'larry06@hotmail.com', '488-855-3620x829', 2);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (55, 'Patrick', 'Marshall', TO_DATE('1961-10-19', 'YYYY-MM-DD'), 'Female', 'rachelcox@gmail.com', '+1-357-039-3426x17', 1);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (56, 'Michelle', 'Jacobson', TO_DATE('2007-04-20', 'YYYY-MM-DD'), 'Male', 'frankmclean@walters-shepard.com', '(595)140-7043x66660', 1);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (57, 'Brandi', 'Gomez', TO_DATE('1998-01-12', 'YYYY-MM-DD'), 'Female', 'mark06@mccall-taylor.com', '001-550-131-8705', 1);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (58, 'Sarah', 'Kirk', TO_DATE('1961-01-20', 'YYYY-MM-DD'), 'Male', 'wwhitehead@hotmail.com', '629-264-8022x270', 2);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (59, 'Jessica', 'Stone', TO_DATE('1997-02-02', 'YYYY-MM-DD'), 'Male', 'melvinwillis@gmail.com', '824-345-4487', 2);
INSERT INTO Member (MemberID, FirstName, LastName, DateOfBirth, Gender, Email, Phone, MembershipTypeID) VALUES (60, 'Yolanda', 'Moore', TO_DATE('1989-11-13', 'YYYY-MM-DD'), 'Female', 'chengregory@johnson.com', '793.782.5278', 1);

INSERT INTO ClassSchedule (ScheduleID, ClassID, TrainerID, StartTime, EndTime, DayOfWeek, RoomNumber) VALUES (1, 6, 4, TO_TIMESTAMP('2024-05-01 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-05-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), 'Friday', 'R101');
INSERT INTO ClassSchedule (ScheduleID, ClassID, TrainerID, StartTime, EndTime, DayOfWeek, RoomNumber) VALUES (2, 4, 2, TO_TIMESTAMP('2024-05-01 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-05-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), 'Wednesday', 'R101');
INSERT INTO ClassSchedule (ScheduleID, ClassID, TrainerID, StartTime, EndTime, DayOfWeek, RoomNumber) VALUES (3, 1, 10, TO_TIMESTAMP('2024-05-01 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-05-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), 'Monday', 'R102');
INSERT INTO ClassSchedule (ScheduleID, ClassID, TrainerID, StartTime, EndTime, DayOfWeek, RoomNumber) VALUES (4, 2, 2, TO_TIMESTAMP('2024-05-01 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-05-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), 'Thursday', 'R102');
INSERT INTO ClassSchedule (ScheduleID, ClassID, TrainerID, StartTime, EndTime, DayOfWeek, RoomNumber) VALUES (5, 6, 1, TO_TIMESTAMP('2024-05-01 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-05-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), 'Saturday', 'R101');
INSERT INTO ClassSchedule (ScheduleID, ClassID, TrainerID, StartTime, EndTime, DayOfWeek, RoomNumber) VALUES (6, 5, 7, TO_TIMESTAMP('2024-05-01 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-05-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), 'Friday', 'R101');
INSERT INTO ClassSchedule (ScheduleID, ClassID, TrainerID, StartTime, EndTime, DayOfWeek, RoomNumber) VALUES (7, 3, 2, TO_TIMESTAMP('2024-05-01 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-05-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), 'Tuesday', 'R101');
INSERT INTO ClassSchedule (ScheduleID, ClassID, TrainerID, StartTime, EndTime, DayOfWeek, RoomNumber) VALUES (8, 6, 5, TO_TIMESTAMP('2024-05-01 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-05-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), 'Wednesday', 'R202');
INSERT INTO ClassSchedule (ScheduleID, ClassID, TrainerID, StartTime, EndTime, DayOfWeek, RoomNumber) VALUES (9, 2, 1, TO_TIMESTAMP('2024-05-01 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-05-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), 'Friday', 'R202');
INSERT INTO ClassSchedule (ScheduleID, ClassID, TrainerID, StartTime, EndTime, DayOfWeek, RoomNumber) VALUES (10, 1, 10, TO_TIMESTAMP('2024-05-01 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-05-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), 'Monday', 'R202');
INSERT INTO ClassSchedule (ScheduleID, ClassID, TrainerID, StartTime, EndTime, DayOfWeek, RoomNumber) VALUES (11, 2, 5, TO_TIMESTAMP('2024-05-01 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-05-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), 'Wednesday', 'R202');
INSERT INTO ClassSchedule (ScheduleID, ClassID, TrainerID, StartTime, EndTime, DayOfWeek, RoomNumber) VALUES (12, 5, 3, TO_TIMESTAMP('2024-05-01 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-05-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), 'Saturday', 'R102');
INSERT INTO ClassSchedule (ScheduleID, ClassID, TrainerID, StartTime, EndTime, DayOfWeek, RoomNumber) VALUES (13, 1, 3, TO_TIMESTAMP('2024-05-01 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-05-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), 'Tuesday', 'R201');
INSERT INTO ClassSchedule (ScheduleID, ClassID, TrainerID, StartTime, EndTime, DayOfWeek, RoomNumber) VALUES (14, 5, 5, TO_TIMESTAMP('2024-05-01 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-05-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), 'Monday', 'R202');
INSERT INTO ClassSchedule (ScheduleID, ClassID, TrainerID, StartTime, EndTime, DayOfWeek, RoomNumber) VALUES (15, 6, 3, TO_TIMESTAMP('2024-05-01 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-05-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), 'Monday', 'R202');
INSERT INTO ClassSchedule (ScheduleID, ClassID, TrainerID, StartTime, EndTime, DayOfWeek, RoomNumber) VALUES (16, 6, 7, TO_TIMESTAMP('2024-05-01 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-05-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), 'Friday', 'R201');
INSERT INTO ClassSchedule (ScheduleID, ClassID, TrainerID, StartTime, EndTime, DayOfWeek, RoomNumber) VALUES (17, 6, 6, TO_TIMESTAMP('2024-05-01 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-05-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), 'Thursday', 'R201');
INSERT INTO ClassSchedule (ScheduleID, ClassID, TrainerID, StartTime, EndTime, DayOfWeek, RoomNumber) VALUES (18, 2, 9, TO_TIMESTAMP('2024-05-01 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-05-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), 'Saturday', 'R101');
INSERT INTO ClassSchedule (ScheduleID, ClassID, TrainerID, StartTime, EndTime, DayOfWeek, RoomNumber) VALUES (19, 4, 2, TO_TIMESTAMP('2024-05-01 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-05-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), 'Wednesday', 'R101');
INSERT INTO ClassSchedule (ScheduleID, ClassID, TrainerID, StartTime, EndTime, DayOfWeek, RoomNumber) VALUES (20, 5, 5, TO_TIMESTAMP('2024-05-01 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2024-05-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), 'Tuesday', 'R102');

INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (1, 49, 16, TO_DATE('2025-04-11', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (2, 23, 20, TO_DATE('2025-03-04', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (3, 19, 12, TO_DATE('2025-04-09', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (4, 38, 20, TO_DATE('2025-03-27', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (5, 9, 10, TO_DATE('2025-04-06', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (6, 25, 14, TO_DATE('2025-03-21', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (7, 54, 3, TO_DATE('2025-04-03', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (8, 1, 20, TO_DATE('2025-03-14', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (9, 13, 11, TO_DATE('2025-03-13', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (10, 11, 8, TO_DATE('2025-03-11', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (11, 15, 15, TO_DATE('2025-04-29', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (12, 25, 19, TO_DATE('2025-04-04', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (13, 56, 14, TO_DATE('2025-03-17', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (14, 3, 13, TO_DATE('2025-03-04', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (15, 56, 19, TO_DATE('2025-04-11', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (16, 27, 2, TO_DATE('2025-04-25', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (17, 11, 15, TO_DATE('2025-04-08', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (18, 5, 9, TO_DATE('2025-04-15', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (19, 45, 6, TO_DATE('2025-03-08', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (20, 29, 17, TO_DATE('2025-03-08', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (21, 57, 16, TO_DATE('2025-04-11', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (22, 59, 18, TO_DATE('2025-04-22', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (23, 39, 1, TO_DATE('2025-04-23', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (24, 57, 2, TO_DATE('2025-03-14', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (25, 32, 11, TO_DATE('2025-03-17', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (26, 20, 15, TO_DATE('2025-03-15', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (27, 4, 14, TO_DATE('2025-03-21', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (28, 13, 18, TO_DATE('2025-03-16', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (29, 41, 3, TO_DATE('2025-03-23', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (30, 54, 5, TO_DATE('2025-03-03', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (31, 1, 13, TO_DATE('2025-04-21', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (32, 44, 14, TO_DATE('2025-03-14', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (33, 21, 1, TO_DATE('2025-04-17', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (34, 14, 1, TO_DATE('2025-04-04', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (35, 46, 1, TO_DATE('2025-03-28', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (36, 53, 17, TO_DATE('2025-04-02', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (37, 40, 4, TO_DATE('2025-03-12', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (38, 13, 4, TO_DATE('2025-04-09', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (39, 39, 7, TO_DATE('2025-03-26', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (40, 56, 10, TO_DATE('2025-03-16', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (41, 18, 6, TO_DATE('2025-04-03', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (42, 7, 16, TO_DATE('2025-04-18', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (43, 55, 13, TO_DATE('2025-04-02', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (44, 41, 3, TO_DATE('2025-04-21', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (45, 2, 9, TO_DATE('2025-03-15', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (46, 59, 15, TO_DATE('2025-04-06', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (47, 52, 4, TO_DATE('2025-04-23', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (48, 56, 9, TO_DATE('2025-03-30', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (49, 9, 17, TO_DATE('2025-03-23', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (50, 53, 12, TO_DATE('2025-04-06', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (51, 8, 5, TO_DATE('2025-04-03', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (52, 18, 1, TO_DATE('2025-04-07', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (53, 3, 2, TO_DATE('2025-04-15', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (54, 14, 9, TO_DATE('2025-04-19', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (55, 36, 11, TO_DATE('2025-03-30', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (56, 24, 19, TO_DATE('2025-04-09', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (57, 59, 2, TO_DATE('2025-04-09', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (58, 55, 20, TO_DATE('2025-03-10', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (59, 42, 16, TO_DATE('2025-03-15', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (60, 46, 15, TO_DATE('2025-03-15', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (61, 41, 14, TO_DATE('2025-03-01', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (62, 24, 18, TO_DATE('2025-04-26', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (63, 12, 7, TO_DATE('2025-04-27', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (64, 25, 19, TO_DATE('2025-04-20', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (65, 19, 1, TO_DATE('2025-03-11', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (66, 9, 5, TO_DATE('2025-03-20', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (67, 18, 11, TO_DATE('2025-04-27', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (68, 22, 12, TO_DATE('2025-04-28', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (69, 46, 3, TO_DATE('2025-04-19', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (70, 22, 20, TO_DATE('2025-03-11', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (71, 3, 2, TO_DATE('2025-03-26', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (72, 18, 6, TO_DATE('2025-04-29', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (73, 10, 19, TO_DATE('2025-03-17', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (74, 19, 12, TO_DATE('2025-04-06', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (75, 26, 18, TO_DATE('2025-03-09', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (76, 9, 10, TO_DATE('2025-03-04', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (77, 8, 16, TO_DATE('2025-03-02', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (78, 47, 8, TO_DATE('2025-03-12', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (79, 60, 2, TO_DATE('2025-04-05', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (80, 20, 6, TO_DATE('2025-04-16', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (81, 55, 17, TO_DATE('2025-03-31', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (82, 47, 3, TO_DATE('2025-03-11', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (83, 20, 13, TO_DATE('2025-04-13', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (84, 54, 11, TO_DATE('2025-04-05', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (85, 20, 14, TO_DATE('2025-04-26', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (86, 7, 4, TO_DATE('2025-03-25', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (87, 36, 16, TO_DATE('2025-04-17', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (88, 31, 11, TO_DATE('2025-03-23', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (89, 54, 11, TO_DATE('2025-03-16', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (90, 8, 16, TO_DATE('2025-04-24', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (91, 8, 16, TO_DATE('2025-04-23', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (92, 28, 2, TO_DATE('2025-03-08', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (93, 20, 11, TO_DATE('2025-04-19', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (94, 48, 5, TO_DATE('2025-03-17', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (95, 59, 6, TO_DATE('2025-03-03', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (96, 41, 19, TO_DATE('2025-03-17', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (97, 25, 3, TO_DATE('2025-04-20', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (98, 5, 3, TO_DATE('2025-04-09', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (99, 13, 8, TO_DATE('2025-04-29', 'YYYY-MM-DD'));
INSERT INTO ClassEnrollment (EnrollmentID, MemberID, ScheduleID, EnrollmentDate) VALUES (100, 4, 13, TO_DATE('2025-03-21', 'YYYY-MM-DD'));

INSERT INTO PersonalTrainingSession (SessionID, MemberID, TrainerID, SessionDate, Duration) VALUES (1, 1, 2, TO_DATE('2025-04-21', 'YYYY-MM-DD'), 45);
INSERT INTO PersonalTrainingSession (SessionID, MemberID, TrainerID, SessionDate, Duration) VALUES (2, 36, 9, TO_DATE('2025-04-19', 'YYYY-MM-DD'), 45);
INSERT INTO PersonalTrainingSession (SessionID, MemberID, TrainerID, SessionDate, Duration) VALUES (3, 29, 8, TO_DATE('2025-04-12', 'YYYY-MM-DD'), 60);
INSERT INTO PersonalTrainingSession (SessionID, MemberID, TrainerID, SessionDate, Duration) VALUES (4, 46, 4, TO_DATE('2025-04-01', 'YYYY-MM-DD'), 45);
INSERT INTO PersonalTrainingSession (SessionID, MemberID, TrainerID, SessionDate, Duration) VALUES (5, 6, 6, TO_DATE('2025-04-28', 'YYYY-MM-DD'), 30);
INSERT INTO PersonalTrainingSession (SessionID, MemberID, TrainerID, SessionDate, Duration) VALUES (6, 17, 10, TO_DATE('2025-04-06', 'YYYY-MM-DD'), 30);
INSERT INTO PersonalTrainingSession (SessionID, MemberID, TrainerID, SessionDate, Duration) VALUES (7, 28, 4, TO_DATE('2025-04-18', 'YYYY-MM-DD'), 45);
INSERT INTO PersonalTrainingSession (SessionID, MemberID, TrainerID, SessionDate, Duration) VALUES (8, 8, 2, TO_DATE('2025-04-08', 'YYYY-MM-DD'), 60);
INSERT INTO PersonalTrainingSession (SessionID, MemberID, TrainerID, SessionDate, Duration) VALUES (9, 2, 9, TO_DATE('2025-04-21', 'YYYY-MM-DD'), 45);
INSERT INTO PersonalTrainingSession (SessionID, MemberID, TrainerID, SessionDate, Duration) VALUES (10, 49, 4, TO_DATE('2025-04-27', 'YYYY-MM-DD'), 30);
INSERT INTO PersonalTrainingSession (SessionID, MemberID, TrainerID, SessionDate, Duration) VALUES (11, 32, 7, TO_DATE('2025-04-02', 'YYYY-MM-DD'), 45);
INSERT INTO PersonalTrainingSession (SessionID, MemberID, TrainerID, SessionDate, Duration) VALUES (12, 14, 1, TO_DATE('2025-04-18', 'YYYY-MM-DD'), 30);
INSERT INTO PersonalTrainingSession (SessionID, MemberID, TrainerID, SessionDate, Duration) VALUES (13, 40, 3, TO_DATE('2025-04-04', 'YYYY-MM-DD'), 30);
INSERT INTO PersonalTrainingSession (SessionID, MemberID, TrainerID, SessionDate, Duration) VALUES (14, 13, 8, TO_DATE('2025-04-28', 'YYYY-MM-DD'), 45);
INSERT INTO PersonalTrainingSession (SessionID, MemberID, TrainerID, SessionDate, Duration) VALUES (15, 24, 9, TO_DATE('2025-04-19', 'YYYY-MM-DD'), 30);
INSERT INTO PersonalTrainingSession (SessionID, MemberID, TrainerID, SessionDate, Duration) VALUES (16, 7, 10, TO_DATE('2025-04-16', 'YYYY-MM-DD'), 45);
INSERT INTO PersonalTrainingSession (SessionID, MemberID, TrainerID, SessionDate, Duration) VALUES (17, 10, 10, TO_DATE('2025-04-11', 'YYYY-MM-DD'), 45);
INSERT INTO PersonalTrainingSession (SessionID, MemberID, TrainerID, SessionDate, Duration) VALUES (18, 41, 7, TO_DATE('2025-04-24', 'YYYY-MM-DD'), 60);
INSERT INTO PersonalTrainingSession (SessionID, MemberID, TrainerID, SessionDate, Duration) VALUES (19, 32, 6, TO_DATE('2025-04-22', 'YYYY-MM-DD'), 45);
INSERT INTO PersonalTrainingSession (SessionID, MemberID, TrainerID, SessionDate, Duration) VALUES (20, 32, 4, TO_DATE('2025-04-01', 'YYYY-MM-DD'), 60);
INSERT INTO PersonalTrainingSession (SessionID, MemberID, TrainerID, SessionDate, Duration) VALUES (21, 40, 4, TO_DATE('2025-04-23', 'YYYY-MM-DD'), 30);
INSERT INTO PersonalTrainingSession (SessionID, MemberID, TrainerID, SessionDate, Duration) VALUES (22, 22, 6, TO_DATE('2025-04-04', 'YYYY-MM-DD'), 45);
INSERT INTO PersonalTrainingSession (SessionID, MemberID, TrainerID, SessionDate, Duration) VALUES (23, 3, 9, TO_DATE('2025-04-13', 'YYYY-MM-DD'), 30);
INSERT INTO PersonalTrainingSession (SessionID, MemberID, TrainerID, SessionDate, Duration) VALUES (24, 56, 5, TO_DATE('2025-04-24', 'YYYY-MM-DD'), 60);
INSERT INTO PersonalTrainingSession (SessionID, MemberID, TrainerID, SessionDate, Duration) VALUES (25, 51, 3, TO_DATE('2025-04-23', 'YYYY-MM-DD'), 45);
INSERT INTO PersonalTrainingSession (SessionID, MemberID, TrainerID, SessionDate, Duration) VALUES (26, 38, 5, TO_DATE('2025-04-26', 'YYYY-MM-DD'), 60);
INSERT INTO PersonalTrainingSession (SessionID, MemberID, TrainerID, SessionDate, Duration) VALUES (27, 46, 8, TO_DATE('2025-04-19', 'YYYY-MM-DD'), 30);
INSERT INTO PersonalTrainingSession (SessionID, MemberID, TrainerID, SessionDate, Duration) VALUES (28, 52, 2, TO_DATE('2025-04-22', 'YYYY-MM-DD'), 60);
INSERT INTO PersonalTrainingSession (SessionID, MemberID, TrainerID, SessionDate, Duration) VALUES (29, 56, 1, TO_DATE('2025-04-12', 'YYYY-MM-DD'), 30);
INSERT INTO PersonalTrainingSession (SessionID, MemberID, TrainerID, SessionDate, Duration) VALUES (30, 15, 3, TO_DATE('2025-04-08', 'YYYY-MM-DD'), 30);
INSERT INTO PersonalTrainingSession (SessionID, MemberID, TrainerID, SessionDate, Duration) VALUES (31, 20, 1, TO_DATE('2025-04-11', 'YYYY-MM-DD'), 45);
INSERT INTO PersonalTrainingSession (SessionID, MemberID, TrainerID, SessionDate, Duration) VALUES (32, 22, 3, TO_DATE('2025-04-26', 'YYYY-MM-DD'), 30);
INSERT INTO PersonalTrainingSession (SessionID, MemberID, TrainerID, SessionDate, Duration) VALUES (33, 56, 8, TO_DATE('2025-04-17', 'YYYY-MM-DD'), 45);
INSERT INTO PersonalTrainingSession (SessionID, MemberID, TrainerID, SessionDate, Duration) VALUES (34, 33, 7, TO_DATE('2025-04-07', 'YYYY-MM-DD'), 60);
INSERT INTO PersonalTrainingSession (SessionID, MemberID, TrainerID, SessionDate, Duration) VALUES (35, 33, 1, TO_DATE('2025-04-14', 'YYYY-MM-DD'), 60);


INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (1, 1, TO_DATE('2025-04-29', 'YYYY-MM-DD'), 25.0, 'Online');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (2, 2, TO_DATE('2025-04-06', 'YYYY-MM-DD'), 60.0, 'Online');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (3, 3, TO_DATE('2025-04-22', 'YYYY-MM-DD'), 25.0, 'Online');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (4, 4, TO_DATE('2025-04-03', 'YYYY-MM-DD'), 30.0, 'Credit Card');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (5, 5, TO_DATE('2025-04-03', 'YYYY-MM-DD'), 30.0, 'Online');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (6, 6, TO_DATE('2025-04-23', 'YYYY-MM-DD'), 60.0, 'Cash');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (7, 7, TO_DATE('2025-04-19', 'YYYY-MM-DD'), 30.0, 'Cash');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (8, 8, TO_DATE('2025-04-27', 'YYYY-MM-DD'), 60.0, 'Online');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (9, 9, TO_DATE('2025-04-19', 'YYYY-MM-DD'), 25.0, 'Credit Card');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (10, 10, TO_DATE('2025-04-26', 'YYYY-MM-DD'), 60.0, 'Credit Card');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (11, 11, TO_DATE('2025-04-04', 'YYYY-MM-DD'), 60.0, 'Credit Card');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (12, 12, TO_DATE('2025-04-12', 'YYYY-MM-DD'), 30.0, 'Online');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (13, 13, TO_DATE('2025-04-23', 'YYYY-MM-DD'), 60.0, 'Cash');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (14, 14, TO_DATE('2025-04-11', 'YYYY-MM-DD'), 30.0, 'Credit Card');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (15, 15, TO_DATE('2025-04-05', 'YYYY-MM-DD'), 30.0, 'Cash');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (16, 16, TO_DATE('2025-04-14', 'YYYY-MM-DD'), 30.0, 'Cash');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (17, 17, TO_DATE('2025-04-06', 'YYYY-MM-DD'), 30.0, 'Cash');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (18, 18, TO_DATE('2025-04-17', 'YYYY-MM-DD'), 25.0, 'Credit Card');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (19, 19, TO_DATE('2025-04-04', 'YYYY-MM-DD'), 60.0, 'Credit Card');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (20, 20, TO_DATE('2025-04-06', 'YYYY-MM-DD'), 25.0, 'Cash');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (21, 21, TO_DATE('2025-04-02', 'YYYY-MM-DD'), 60.0, 'Cash');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (22, 22, TO_DATE('2025-04-06', 'YYYY-MM-DD'), 25.0, 'Credit Card');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (23, 23, TO_DATE('2025-04-28', 'YYYY-MM-DD'), 30.0, 'Cash');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (24, 24, TO_DATE('2025-04-27', 'YYYY-MM-DD'), 25.0, 'Cash');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (25, 25, TO_DATE('2025-04-09', 'YYYY-MM-DD'), 60.0, 'Online');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (26, 26, TO_DATE('2025-03-31', 'YYYY-MM-DD'), 25.0, 'Online');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (27, 27, TO_DATE('2025-04-01', 'YYYY-MM-DD'), 60.0, 'Credit Card');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (28, 28, TO_DATE('2025-04-19', 'YYYY-MM-DD'), 30.0, 'Cash');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (29, 29, TO_DATE('2025-04-27', 'YYYY-MM-DD'), 25.0, 'Online');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (30, 30, TO_DATE('2025-04-29', 'YYYY-MM-DD'), 30.0, 'Cash');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (31, 31, TO_DATE('2025-04-23', 'YYYY-MM-DD'), 30.0, 'Credit Card');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (32, 32, TO_DATE('2025-04-05', 'YYYY-MM-DD'), 25.0, 'Cash');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (33, 33, TO_DATE('2025-04-22', 'YYYY-MM-DD'), 25.0, 'Credit Card');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (34, 34, TO_DATE('2025-04-27', 'YYYY-MM-DD'), 25.0, 'Online');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (35, 35, TO_DATE('2025-04-16', 'YYYY-MM-DD'), 60.0, 'Credit Card');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (36, 36, TO_DATE('2025-04-16', 'YYYY-MM-DD'), 60.0, 'Cash');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (37, 37, TO_DATE('2025-04-04', 'YYYY-MM-DD'), 25.0, 'Online');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (38, 38, TO_DATE('2025-03-31', 'YYYY-MM-DD'), 60.0, 'Online');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (39, 39, TO_DATE('2025-04-11', 'YYYY-MM-DD'), 30.0, 'Credit Card');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (40, 40, TO_DATE('2025-04-11', 'YYYY-MM-DD'), 30.0, 'Cash');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (41, 41, TO_DATE('2025-04-24', 'YYYY-MM-DD'), 25.0, 'Credit Card');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (42, 42, TO_DATE('2025-04-15', 'YYYY-MM-DD'), 60.0, 'Online');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (43, 43, TO_DATE('2025-04-13', 'YYYY-MM-DD'), 30.0, 'Online');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (44, 44, TO_DATE('2025-04-10', 'YYYY-MM-DD'), 60.0, 'Cash');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (45, 45, TO_DATE('2025-03-31', 'YYYY-MM-DD'), 60.0, 'Credit Card');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (46, 46, TO_DATE('2025-04-24', 'YYYY-MM-DD'), 60.0, 'Online');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (47, 47, TO_DATE('2025-04-17', 'YYYY-MM-DD'), 60.0, 'Cash');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (48, 48, TO_DATE('2025-04-24', 'YYYY-MM-DD'), 25.0, 'Cash');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (49, 49, TO_DATE('2025-04-16', 'YYYY-MM-DD'), 30.0, 'Online');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (50, 50, TO_DATE('2025-04-04', 'YYYY-MM-DD'), 60.0, 'Credit Card');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (51, 51, TO_DATE('2025-04-03', 'YYYY-MM-DD'), 60.0, 'Credit Card');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (52, 52, TO_DATE('2025-04-14', 'YYYY-MM-DD'), 25.0, 'Cash');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (53, 53, TO_DATE('2025-04-27', 'YYYY-MM-DD'), 30.0, 'Cash');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (54, 54, TO_DATE('2025-04-20', 'YYYY-MM-DD'), 25.0, 'Cash');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (55, 55, TO_DATE('2025-04-10', 'YYYY-MM-DD'), 30.0, 'Online');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (56, 56, TO_DATE('2025-04-17', 'YYYY-MM-DD'), 25.0, 'Credit Card');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (57, 57, TO_DATE('2025-04-18', 'YYYY-MM-DD'), 25.0, 'Cash');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (58, 58, TO_DATE('2025-04-07', 'YYYY-MM-DD'), 30.0, 'Credit Card');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (59, 59, TO_DATE('2025-04-11', 'YYYY-MM-DD'), 60.0, 'Online');
INSERT INTO Payment (PaymentID, MemberID, PaymentDate, Amount, PaymentMethod) VALUES (60, 60, TO_DATE('2025-04-13', 'YYYY-MM-DD'), 60.0, 'Online');


-- Membership Types
SELECT * FROM MembershipType;

-- Members
SELECT * FROM Member;

-- Trainers
SELECT * FROM Trainer;

-- Fitness Classes
SELECT * FROM FitnessClass;

-- Class Schedule
SELECT * FROM ClassSchedule;

-- Class Enrollments
SELECT * FROM ClassEnrollment;

-- Personal Training Sessions
SELECT * FROM PersonalTrainingSession;

-- Payments
SELECT * FROM Payment;

-- 1. Top Earning Membership Type

SELECT mt.TypeName, SUM(p.Amount) AS TotalRevenue
FROM Payment p
JOIN Member m ON p.MemberID = m.MemberID
JOIN MembershipType mt ON m.MembershipTypeID = mt.MembershipTypeID
GROUP BY mt.TypeName
ORDER BY TotalRevenue DESC;

-- 2. Most Popular Fitness Classes

SELECT fc.ClassName, COUNT(*) AS Enrollments
FROM ClassEnrollment ce
JOIN ClassSchedule cs ON ce.ScheduleID = cs.ScheduleID
JOIN FitnessClass fc ON cs.ClassID = fc.ClassID
GROUP BY fc.ClassName
ORDER BY Enrollments DESC;

-- 3. Most Active Trainers

SELECT t.FirstName || ' ' || t.LastName AS TrainerName, COUNT(*) AS Sessions
FROM PersonalTrainingSession pts
JOIN Trainer t ON pts.TrainerID = t.TrainerID
GROUP BY TrainerName
ORDER BY Sessions DESC;

-- 4. Member Class Participation (Weekly Average)

SELECT m.MemberID, m.FirstName || ' ' || m.LastName AS Name, COUNT(*) / 4 AS AvgClassesPerWeek
FROM ClassEnrollment ce
JOIN Member m ON ce.MemberID = m.MemberID
GROUP BY m.MemberID, m.FirstName, m.LastName;

-- 5. Busiest Day of the Week

SELECT cs.DayOfWeek, COUNT(*) AS TotalEnrollments
FROM ClassEnrollment ce
JOIN ClassSchedule cs ON ce.ScheduleID = cs.ScheduleID
GROUP BY cs.DayOfWeek
ORDER BY TotalEnrollments DESC;

-- 6. Members with Zero Class Enrollments

SELECT m.MemberID, m.FirstName, m.LastName
FROM Member m
WHERE NOT EXISTS (
    SELECT 1 FROM ClassEnrollment ce WHERE ce.MemberID = m.MemberID
);

-- 7. Premium Members and Class Usage

SELECT m.MemberID, m.FirstName || ' ' || m.LastName AS Name, COUNT(ce.EnrollmentID) AS ClassesAttended
FROM Member m
LEFT JOIN ClassEnrollment ce ON m.MemberID = ce.MemberID
WHERE m.MembershipTypeID = 2
GROUP BY m.MemberID, m.FirstName, m.LastName
ORDER BY ClassesAttended DESC;

-- 8. Total Revenue for the Past 30 Days

SELECT SUM(Amount) AS TotalRevenueLast30Days
FROM Payment
WHERE PaymentDate >= SYSDATE - 30;