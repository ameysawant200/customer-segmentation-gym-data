-- 1. Top Earning Membership Type

SELECT mt.TypeName, SUM(p.Amount) AS TotalRevenue
FROM Payment p
JOIN Member m ON p.MemberID = m.MemberID
JOIN MembershipType mt ON m.MembershipTypeID = mt.MembershipTypeID
GROUP BY mt.TypeName
ORDER BY TotalRevenue DESC;

-- 2. Most Popular Fitness Classes

SELECT fc.ClassName, COUNT(*) AS Enrollments
FROM ClassEnrollment ce
JOIN ClassSchedule cs ON ce.ScheduleID = cs.ScheduleID
JOIN FitnessClass fc ON cs.ClassID = fc.ClassID
GROUP BY fc.ClassName
ORDER BY Enrollments DESC;

-- 3. Most Active Trainers

SELECT t.FirstName || ' ' || t.LastName AS TrainerName, COUNT(*) AS Sessions
FROM PersonalTrainingSession pts
JOIN Trainer t ON pts.TrainerID = t.TrainerID
GROUP BY TrainerName
ORDER BY Sessions DESC;

-- 4. Member Class Participation (Weekly Average)

SELECT m.MemberID, m.FirstName || ' ' || m.LastName AS Name, COUNT(*) / 4 AS AvgClassesPerWeek
FROM ClassEnrollment ce
JOIN Member m ON ce.MemberID = m.MemberID
GROUP BY m.MemberID, m.FirstName, m.LastName;

-- 5. Busiest Day of the Week

SELECT cs.DayOfWeek, COUNT(*) AS TotalEnrollments
FROM ClassEnrollment ce
JOIN ClassSchedule cs ON ce.ScheduleID = cs.ScheduleID
GROUP BY cs.DayOfWeek
ORDER BY TotalEnrollments DESC;

-- 6. Members with Zero Class Enrollments

SELECT m.MemberID, m.FirstName, m.LastName
FROM Member m
WHERE NOT EXISTS (
    SELECT 1 FROM ClassEnrollment ce WHERE ce.MemberID = m.MemberID
);

-- 7. Premium Members and Class Usage

SELECT m.MemberID, m.FirstName || ' ' || m.LastName AS Name, COUNT(ce.EnrollmentID) AS ClassesAttended
FROM Member m
LEFT JOIN ClassEnrollment ce ON m.MemberID = ce.MemberID
WHERE m.MembershipTypeID = 2
GROUP BY m.MemberID, m.FirstName, m.LastName
ORDER BY ClassesAttended DESC;

-- 8. Total Revenue for the Past 30 Days

SELECT SUM(Amount) AS TotalRevenueLast30Days
FROM Payment
WHERE PaymentDate >= SYSDATE - 30;